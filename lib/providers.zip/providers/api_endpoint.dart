 const BASE_URL = "http://afexworkbenchdev.com";
const BASE_API_URL = "$BASE_URL/WB3/api/v1/";
const ENDPOINT_GET_FARMER_LIST = "farmer/list";


//END POINTS