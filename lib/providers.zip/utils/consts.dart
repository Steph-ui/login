
const KEY_DATA = "data";
const KEY_MESSAGE = "message";
const KEY_RESPONSE_CODE = "responseCode";
const KEY_NEXT = "next";
const KEY_PREVIOUS = "previous";
const KEY_COUNT = "count";

const KEY_FIRST_NAME = "first_name";
const KEY_LAST_NAME = "last_name";
const KEY_PICTURE = "photo_url";
const KEY_COOPERATIVE = "cooperative";
const KEY_FOLIO_ID = "folio_id";

const KEY_CONTENT_TYPE = "content-type";
const KEY_AUTHORIZATION = "Authorization";